# F2Depine
La mejor catedra

## Requisitos para usar la "librería":
-numpy
-matplotlib
-scipy

## para quienes usen VirtualEnvs:

> virtaulenv env  &nbsp;
>  source env/bin/activate &nbsp;
>  pip install -r requirements.txt &nbsp;
 

